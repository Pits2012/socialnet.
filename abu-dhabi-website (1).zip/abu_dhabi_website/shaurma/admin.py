from django.contrib import admin
from .models import MenuCategory, MenuItem, MenuItemVariant


@admin.register(MenuCategory)
class MenuCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'subtitle', 'order')
    ordering = ('order',)


class MenuItemVariantInline(admin.TabularInline):
    model = MenuItemVariant
    extra = 1


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'is_spicy', 'is_vegetarian', 'is_available')
    list_filter = ('category', 'is_spicy', 'is_vegetarian', 'is_available')
    search_fields = ('name', 'description')
    list_editable = ('is_available',)
    inlines = [MenuItemVariantInline]
