from django.db import models


class MenuCategory(models.Model):
    """Категорія меню, напр. 'Шаурма', 'Напої', 'Соуси'."""
    name = models.CharField('Назва категорії', max_length=100)
    subtitle = models.CharField(
        'Підзаголовок', max_length=200, blank=True,
        help_text='Короткий підпис під назвою категорії, необов’язково'
    )
    order = models.PositiveIntegerField('Порядок відображення', default=0)

    class Meta:
        verbose_name = 'Категорія меню'
        verbose_name_plural = 'Категорії меню'
        ordering = ['order', 'name']

    def __str__(self):
        return self.name


class MenuItem(models.Model):
    """Одна позиція меню. Якщо страва продається в кількох розмірах
    (S/M/L/XL), додайте варіанти нижче замість заповнення поля 'Ціна'."""
    category = models.ForeignKey(
        MenuCategory, on_delete=models.CASCADE, related_name='items',
        verbose_name='Категорія'
    )
    name = models.CharField('Назва страви', max_length=150)
    description = models.TextField('Опис', blank=True)
    price = models.DecimalField(
        'Ціна (грн)', max_digits=7, decimal_places=2, blank=True, null=True,
        help_text='Залиште порожнім, якщо нижче додані варіанти розмірів (S/M/L/XL)'
    )
    weight = models.CharField('Вага/об’єм', max_length=50, blank=True, help_text='напр. 300 г, 0.5 л')
    image = models.ImageField('Фото', upload_to='menu/', blank=True, null=True)
    is_spicy = models.BooleanField('Гостре', default=False)
    is_vegetarian = models.BooleanField('Вегетаріанське', default=False)
    is_available = models.BooleanField('Доступне', default=True)
    order = models.PositiveIntegerField('Порядок відображення', default=0)

    class Meta:
        verbose_name = 'Позиція меню'
        verbose_name_plural = 'Позиції меню'
        ordering = ['category__order', 'order', 'name']

    def __str__(self):
        if self.price is not None:
            return f'{self.name} — {self.price} грн'
        return self.name

    @property
    def price_from(self):
        """Найменша ціна серед варіантів (для карток 'від ... грн')."""
        variant = self.variants.order_by('price').first()
        return variant.price if variant else None


class MenuItemVariant(models.Model):
    """Варіант розміру страви, напр. S/M/L/XL з окремою ціною."""
    item = models.ForeignKey(
        MenuItem, on_delete=models.CASCADE, related_name='variants',
        verbose_name='Позиція меню'
    )
    label = models.CharField('Розмір/варіант', max_length=30, help_text='напр. S, M, L, XL')
    price = models.DecimalField('Ціна (грн)', max_digits=7, decimal_places=2)
    order = models.PositiveIntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Варіант розміру'
        verbose_name_plural = 'Варіанти розмірів'
        ordering = ['order', 'id']

    def __str__(self):
        return f'{self.item.name} {self.label} — {self.price} грн'
