from django.conf import settings


def site_info(request):
    """Робить SITE_INFO (телефон, адреса, години роботи) доступним у будь-якому шаблоні."""
    return {'site_info': settings.SITE_INFO}
