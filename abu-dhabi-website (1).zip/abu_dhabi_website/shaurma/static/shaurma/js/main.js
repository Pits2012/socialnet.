// ==========================================================================
// Абу Дабі — базові анімації та інтерактивність (без залежностей)
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

    /* ---- Scroll-reveal: елементи з класом .reveal плавно з'являються ---- */
    var revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && revealEls.length) {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        revealEls.forEach(function (el) { observer.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add('is-visible'); });
    }

    /* ---- Header: змінює вигляд і "стискається" при прокрутці ---- */
    var header = document.getElementById('siteHeader');
    if (header) {
        var onScroll = function () {
            if (window.scrollY > 24) header.classList.add('is-scrolled');
            else header.classList.remove('is-scrolled');
        };
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    }

    /* ---- Мобільне меню ---- */
    var navToggle = document.getElementById('navToggle');
    var mainNav = document.getElementById('mainNav');
    if (navToggle && mainNav) {
        navToggle.addEventListener('click', function () {
            mainNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active');
        });
        mainNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                mainNav.classList.remove('is-open');
                navToggle.classList.remove('is-active');
            });
        });
    }

    /* ---- Плавний скрол і активна вкладка для табів меню ---- */
    var tabs = document.querySelectorAll('.menu-tab');
    if (tabs.length) {
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function (e) {
                var targetId = tab.getAttribute('href');
                var target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    var headerHeight = header ? header.offsetHeight + 56 : 70;
                    var top = target.getBoundingClientRect().top + window.scrollY - headerHeight;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                }
            });
        });

        var sections = Array.prototype.map.call(tabs, function (tab) {
            return document.querySelector(tab.getAttribute('href'));
        }).filter(Boolean);

        if ('IntersectionObserver' in window) {
            var tabObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    var id = '#' + entry.target.id;
                    var matchingTab = document.querySelector('.menu-tab[href="' + id + '"]');
                    if (!matchingTab) return;
                    if (entry.isIntersecting) {
                        tabs.forEach(function (t) { t.classList.remove('is-active'); });
                        matchingTab.classList.add('is-active');
                    }
                });
            }, { rootMargin: '-40% 0px -50% 0px' });

            sections.forEach(function (section) { tabObserver.observe(section); });
        }
    }
});
