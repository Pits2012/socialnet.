from django.apps import AppConfig


class ShaurmaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shaurma'
    verbose_name = 'Шаурмічна "Абу Дабі"'
