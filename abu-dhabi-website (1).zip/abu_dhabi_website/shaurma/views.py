from django.shortcuts import render
from .models import MenuCategory


def home(request):
    """Головна сторінка з коротким вступом та 4 хітами меню."""
    featured = MenuCategory.objects.prefetch_related('items__variants').first()
    featured_items = featured.items.filter(is_available=True)[:4] if featured else []
    return render(request, 'shaurma/home.html', {'featured_items': featured_items})


def menu(request):
    """Повне меню, згруповане за категоріями."""
    categories = MenuCategory.objects.prefetch_related('items__variants').all()
    return render(request, 'shaurma/menu.html', {'categories': categories})


def contacts(request):
    """Сторінка контактів: адреса, телефон, години роботи, карта."""
    return render(request, 'shaurma/contacts.html')


def delivery(request):
    """Сторінка про самовивіз та доставку на таксі."""
    return render(request, 'shaurma/delivery.html')
