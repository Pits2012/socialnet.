from django.core.management.base import BaseCommand
from shaurma.models import MenuCategory, MenuItem, MenuItemVariant


class Command(BaseCommand):
    help = 'Наповнює базу реальним меню шаурмічної "Абу Дабі" (на основі наданих фото меню)'

    def handle(self, *args, **options):
        # Очищаємо старі дані, щоб уникнути дублів при повторному запуску
        MenuCategory.objects.all().delete()

        # ------------------------------------------------------------------
        # 1. Standart Shawarma — курка/телятина з розмірами S/M/L/XL
        # ------------------------------------------------------------------
        cat_shawarma = MenuCategory.objects.create(
            name='Standart Shawarma',
            subtitle='Соковите м’ясо, хрусткий лаваш, свіжі овочі та фірмові соуси',
            order=0,
        )

        chicken = MenuItem.objects.create(
            category=cat_shawarma, name='Шаурма з куркою',
            description='Ніжна курка, свіжі овочі, фірмовий соус у теплому лаваші',
            order=0,
        )
        for label, price in [('S', 80), ('M', 120), ('L', 160), ('XL', 230)]:
            MenuItemVariant.objects.create(item=chicken, label=label, price=price)

        veal = MenuItem.objects.create(
            category=cat_shawarma, name='Шаурма з телятиною',
            description='Соковита телятина, свіжі овочі, фірмовий соус у теплому лаваші',
            order=1,
        )
        for label, price in [('S', 100), ('M', 140), ('L', 190), ('XL', 250)]:
            MenuItemVariant.objects.create(item=veal, label=label, price=price)

        MenuItem.objects.create(
            category=cat_shawarma, name='Vegan',
            description='Овочева шаурма без м’яса',
            price=90, is_vegetarian=True, order=2,
        )
        MenuItem.objects.create(
            category=cat_shawarma, name='Арабський хот-дог',
            description='Соковита сосиска, овочі та соус у лаваші',
            price=90, order=3,
        )

        # ------------------------------------------------------------------
        # 2. Додатки — топінги до шаурми
        # ------------------------------------------------------------------
        cat_addons = MenuCategory.objects.create(
            name='Додатки', subtitle='Доповніть свою шаурму', order=1,
        )
        addons = [
            ('Курка', 40), ('Телятина', 50), ('Сосиска', 30),
            ('Картопля', 30), ('Хумус', 30), ('Соус', 20),
            ('Сир', 20), ('Кукурудза', 30), ('Маслини', 30),
        ]
        for i, (name, price) in enumerate(addons):
            MenuItem.objects.create(category=cat_addons, name=name, price=price, order=i)

        # ------------------------------------------------------------------
        # 3. Дюрум (Mixed Menu)
        # ------------------------------------------------------------------
        cat_durum = MenuCategory.objects.create(
            name='Дюрум', subtitle='У щільному лаваші з хрусткою скоринкою', order=2,
        )
        durum_items = [
            ('Durum з куркою', 110),
            ('Durum з телятиною', 130),
            ('Durum з сосискою', 90),
            ('Картопля фрі', 60),
        ]
        for i, (name, price) in enumerate(durum_items):
            MenuItem.objects.create(category=cat_durum, name=name, price=price, order=i)

        # ------------------------------------------------------------------
        # 4. Комбо (Kombo Menu)
        # ------------------------------------------------------------------
        cat_kombo = MenuCategory.objects.create(
            name='Комбо', subtitle='Вигідні набори — шаурма/дюрум + фрі + напій', order=3,
        )
        kombo_items = [
            ('Shawarma M + Pepsi', 110),
            ('Shawarma S + фрі + Pepsi', 130),
            ('Durum курка + фрі + Pepsi', 180),
            ('Doner курка + фрі + Pepsi', 230),
            ('AbuDhabi курка + фрі + Pepsi', 230),
        ]
        for i, (name, price) in enumerate(kombo_items):
            MenuItem.objects.create(category=cat_kombo, name=name, price=price, order=i)

        # ------------------------------------------------------------------
        # 5. Гарячі напої
        # ------------------------------------------------------------------
        cat_hot = MenuCategory.objects.create(name='Гарячі напої', order=4)
        hot_drinks = [
            ('Еспресо', 20), ('Доппіо', 40), ('Еспресо з молоком', 25),
            ('Американо', 20), ('Американо з молоком', 25), ('Капучино', 35),
            ('Латте', 45), ('Гарячий шоколад', 35), ('Чай', 20), ('Живий чай', 40),
        ]
        for i, (name, price) in enumerate(hot_drinks):
            MenuItem.objects.create(category=cat_hot, name=name, price=price, order=i)

        # ------------------------------------------------------------------
        # 6. Холодні напої
        # ------------------------------------------------------------------
        cat_cold = MenuCategory.objects.create(name='Холодні напої', order=5)
        cold_drinks = [
            ('Pepsi, 7up, Mirinda', 35, '0.5 л'),
            ('Pepsi Cola (скло)', 35, '0.33 л'),
            ('Lipton', 35, '0.5 л'),
            ('Сік', 35, '0.5 л'),
            ('Сік Kids', 20, ''),
            ('Вода мінеральна', 20, ''),
        ]
        for i, (name, price, weight) in enumerate(cold_drinks):
            MenuItem.objects.create(category=cat_cold, name=name, price=price, weight=weight, order=i)

        self.stdout.write(self.style.SUCCESS('Меню успішно наповнено реальними даними! Відредагуйте за потреби у /admin/.'))
