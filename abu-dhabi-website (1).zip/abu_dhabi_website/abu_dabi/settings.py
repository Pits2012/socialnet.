"""
Django settings for проєкту "Абу Дабі" — сайт шаурмічної у Чернівцях.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# ВАЖЛИВО: перед деплоєм на продакшн згенеруйте новий SECRET_KEY і
# заберіть його з коду (наприклад, через змінну середовища).
SECRET_KEY = 'django-insecure-change-me-before-deploy-abu-dabi'

DEBUG = True

ALLOWED_HOSTS = ['*']  # На продакшн вкажіть тут свій реальний домен

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'shaurma',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'abu_dabi.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                # Власний контекст-процесор: контакти доступні на кожній сторінці
                'shaurma.context_processors.site_info',
            ],
        },
    },
]

WSGI_APPLICATION = 'abu_dabi.wsgi.application'
ASGI_APPLICATION = 'abu_dabi.asgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'uk-ua'
TIME_ZONE = 'Europe/Kyiv'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ---------------------------------------------------------------------------
# Дані закладу — ЗАМІНІТЬ на реальні перед публікацією сайту.
# Ці значення підставляються на всіх сторінках через context_processors.
# ---------------------------------------------------------------------------
SITE_INFO = {
    'NAME': 'Абу Дабі',
    'PHONE': '+380 99 123 45 67',          # TODO: реальний номер телефону
    'PHONE_RAW': '+380991234567',
    'ADDRESS': 'м. Чернівці, вул. Головна, 1',  # TODO: реальна адреса
    'WORK_HOURS': 'Щодня 10:00–22:00',
    'INSTAGRAM': 'https://instagram.com/',
    'MAP_EMBED': '',  # можна вставити iframe-посилання Google Maps
    # Інформація про самовивіз і доставку (з наданих фото меню)
    'PICKUP_HOURS': '10:00 – 15:00',
    'DELIVERY_WEEKDAYS': '15:00 – 21:00',
    'DELIVERY_WEEKENDS': '11:00 – 21:00',
}
