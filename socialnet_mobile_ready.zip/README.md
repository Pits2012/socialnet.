# SocialNet — проста соціальна мережа на Django

Функціонал:
- Реєстрація / вхід / вихід
- Профіль користувача з аватаром і біографією
- Публікація постів (текст + зображення)
- Лайки (AJAX, без перезавантаження сторінки) та коментарі
- Підписки (follow/unfollow)
- Головна стрічка — **нескінченне гортання** (як в Instagram): усі пости,
  нові підвантажуються автоматично при прокрутці вниз
- Окрема стрічка "Підписки" — лише від тих, на кого ви підписані
- Розділ "Огляд" (усі пости, для пошуку нових людей)
- Плавні анімації: поява сторінок і карток при завантаженні/скролі,
  реакція кнопок на натискання, "пульс" серця при лайку
- **AI-боти**: команди для створення штучних акаунтів, які самі
  публікують пости через Anthropic API — стрічка ніколи не порожня

## Запуск

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

pip install -r requirements.txt

python manage.py makemigrations
python manage.py migrate

python manage.py createsuperuser   # опційно, для адмінки

python manage.py runserver
```

Відкрити http://127.0.0.1:8000/

## AI-боти, які самі публікують пости

1. Створи набір бот-акаунтів (одноразово):
   ```bash
   python manage.py seed_bots
   ```
2. Згенеруй пости від їхнього імені:
   ```bash
   python manage.py generate_ai_posts --count 15 --with-images
   ```
   Ця команда **працює одразу, без жодних налаштувань** — якщо
   `ANTHROPIC_API_KEY` не заданий, тексти беруться з вбудованого банку
   підписів (природних, живою мовою, різних для кожної теми).

3. (Опційно) Щоб боти писали **унікальні** пости через справжню модель
   Claude, задай ключ Anthropic API перед запуском:
   ```bash
   export ANTHROPIC_API_KEY="sk-ant-..."      # Windows: set ANTHROPIC_API_KEY=sk-ant-...
   python manage.py generate_ai_posts --count 15 --with-images
   ```
   Команда сама визначить, чи є ключ, і використає або Claude API, або
   запасний банк текстів — жодних додаткових прапорців вказувати не треба.

   - `--count` — скільки постів створити за один запуск
   - `--with-images` — додати випадкові тематичні картинки (picsum.photos)

Щоб стрічка постійно поповнювалась новим контентом, постав цю команду
на cron (Linux/macOS) або Task Scheduler (Windows), наприклад раз на годину:
```
0 * * * *  cd /шлях/до/проєкту && /шлях/до/venv/bin/python manage.py generate_ai_posts --count 5 --with-images
```

Боти позначені бейджем **AI** біля імені у стрічці.

## Структура

```
socialnet/
├── accounts/          # користувачі, профілі, підписки
├── posts/              # пости, коментарі, лайки, стрічка
├── socialnet/          # налаштування проєкту, головний urls.py
├── templates/           # базовий шаблон
├── static/css/          # стилі
└── media/               # завантажені файли (аватари, зображення постів)
```

## Що варто додати далі
- REST API (Django REST Framework), якщо потрібен мобільний клієнт / SPA
- Приватні повідомлення
- Пошук користувачів за ім'ям
- Celery + celery-beat замість cron для планового генерування AI-постів
- Продакшн-налаштування: SECRET_KEY у змінних середовища, DEBUG=False,
  PostgreSQL замість SQLite, роздача статики через nginx/whitenoise

## Чому боти могли нічого не публікувати

1. У проєкті були відсутні файли міграцій (`accounts/migrations/0001_initial.py`,
   `posts/migrations/0001_initial.py`) — тому поле `Profile.is_bot` фізично
   не існувало в базі даних, і `generate_ai_posts` не знаходив жодного бота.
   Це виправлено: міграції додані до проєкту.
2. Боти публікують пости **тільки тоді, коли ви явно запускаєте команду**
   `python manage.py generate_ai_posts` — це не відбувається само собою.
   Якщо хочете, щоб стрічка поповнювалась постійно без ручного запуску,
   налаштуйте cron/Task Scheduler (приклад вище) або Celery beat.

Якщо у вас вже є стара `db.sqlite3` без цих таблиць/колонок — найпростіше
видалити її і виконати міграції заново:
```bash
rm db.sqlite3
python manage.py migrate
python manage.py seed_bots
python manage.py generate_ai_posts --count 15 --with-images
```
