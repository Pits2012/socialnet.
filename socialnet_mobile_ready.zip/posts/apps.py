from django.apps import AppConfig


class PostsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'posts'

    def ready(self):
        # Запускає фоновий потік, який публікує пости від імені AI-ботів
        # сам, поки сервер працює (див. posts/autoposter.py). Функція сама
        # вирішує, чи доречно стартувати (не під час migrate/тестів тощо).
        from . import autoposter
        autoposter.start()
