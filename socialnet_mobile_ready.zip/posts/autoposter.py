"""Фоновий "автопостинг": поки працює `manage.py runserver` (або WSGI-сервер),
окремий потік раз на кілька хвилин обирає випадкового бота і публікує від
його імені пост — без ручного запуску команд чи налаштування cron.

Це навмисно просте рішення для одного процесу (SQLite + runserver / один
gunicorn-воркер). Якщо в продакшені запускається кілька воркерів, кожен
підніме свій потік — тоді краще вимкнути AI_AUTOPOSTING_ENABLED і
запускати `generate_ai_posts` через Celery beat або системний cron,
щоб пости публікувались рівно з одного місця (детальніше — у README).
"""
import logging
import os
import random
import sys
import threading
import time

logger = logging.getLogger(__name__)

_start_lock = threading.Lock()
_started = False

# Даємо серверу час підняти з'єднання з БД, перш ніж перший запит
_INITIAL_DELAY_SECONDS = 8


def _worker(min_seconds, max_seconds, image_chance):
    from django.db import close_old_connections
    from django.db.utils import OperationalError, ProgrammingError

    from accounts.services import ensure_default_bots
    from .ai_writer import create_ai_post

    time.sleep(_INITIAL_DELAY_SECONDS)
    bots_ready = False

    while True:
        try:
            close_old_connections()
            if not bots_ready:
                ensure_default_bots()
                bots_ready = True
            post = create_ai_post(with_images=random.random() < image_chance)
            logger.info('бот %s опублікував пост: %s', post.author.username, post.text[:60])
        except (OperationalError, ProgrammingError):
            # Таблиці ще не мігровані (перший запуск проєкту) — спробуємо ще раз пізніше.
            logger.warning('БД ще не готова (виконайте `manage.py migrate`) — повторю спробу пізніше.')
            bots_ready = False
        except Exception:
            logger.exception('Не вдалося автоматично опублікувати AI-пост.')
        finally:
            close_old_connections()
            time.sleep(random.uniform(min_seconds, max_seconds))


def _is_server_process():
    """True лише для процесу, який реально обслуговує запити — не для
    manage.py migrate/makemigrations/shell/test тощо, і не для допоміжного
    процесу-спостерігача автоперезавантаження Django в режимі --noreload."""
    argv = sys.argv
    prog = argv[0] if argv else ''

    is_wsgi_server = any(name in prog for name in ('gunicorn', 'uwsgi', 'daphne', 'uvicorn'))
    is_runserver = len(argv) > 1 and argv[1] == 'runserver'

    if not (is_wsgi_server or is_runserver):
        return False

    if is_wsgi_server:
        return True

    # `runserver` з автоперезавантаженням (типово в DEBUG) стартує процес двічі:
    # батьківський "спостерігач" (без RUN_MAIN) і дочірній робочий процес
    # (RUN_MAIN=true). Запускаємо потік лише в тому, що реально працює.
    if '--noreload' in argv:
        return True
    return os.environ.get('RUN_MAIN') == 'true'


def start():
    """Стартує фоновий потік автопостингу (один раз за процес)."""
    from django.conf import settings

    global _started
    with _start_lock:
        if _started:
            return
        if not getattr(settings, 'AI_AUTOPOSTING_ENABLED', True):
            return
        if not _is_server_process():
            return
        _started = True

    min_seconds = getattr(settings, 'AI_AUTOPOST_MIN_SECONDS', 90)
    max_seconds = getattr(settings, 'AI_AUTOPOST_MAX_SECONDS', 240)
    image_chance = getattr(settings, 'AI_AUTOPOST_IMAGE_CHANCE', 0.6)

    thread = threading.Thread(
        target=_worker,
        args=(min_seconds, max_seconds, image_chance),
        name='ai-autoposter',
        daemon=True,
    )
    thread.start()
    logger.info(
        'AI-автопостинг увімкнено: новий пост кожні ~%.1f–%.1f хв.',
        min_seconds / 60, max_seconds / 60,
    )
