import os

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand, CommandError

from posts.ai_writer import create_ai_post


class Command(BaseCommand):
    help = (
        'Генерує пости від імені AI-ботів (створених командою seed_bots). '
        'Якщо задано ANTHROPIC_API_KEY — тексти пише модель Claude через API. '
        'Якщо ключа немає — використовується вбудований банк підписів, '
        'тож команда працює одразу, без додаткового налаштування. '
        'Це ручний/cron-спосіб наповнити стрічку — за замовчуванням боти вже '
        'публікують пости самі у фоні, поки запущено `runserver` '
        '(див. AI_AUTOPOSTING_ENABLED у settings.py).'
    )

    def add_arguments(self, parser):
        parser.add_argument('--count', type=int, default=5, help='Скільки постів згенерувати.')
        parser.add_argument(
            '--with-images', action='store_true',
            help='Додати до постів випадкові тематичні зображення (picsum.photos).'
        )

    def handle(self, *args, **options):
        api_key = os.environ.get('ANTHROPIC_API_KEY')
        if not api_key:
            self.stdout.write(self.style.WARNING(
                'ANTHROPIC_API_KEY не задано — використовую вбудований банк текстів '
                '(без звернення до Claude API). Щоб боти писали унікальні пости '
                'через AI, задай змінну середовища ANTHROPIC_API_KEY і запусти знову.'
            ))

        if not User.objects.filter(profile__is_bot=True).exists():
            raise CommandError(
                'Немає жодного бота. Спочатку виконай: python manage.py seed_bots'
            )

        count = options['count']
        with_images = options['with_images']
        created = 0

        for _ in range(count):
            post = create_ai_post(with_images=with_images, api_key=api_key)
            created += 1
            self.stdout.write(f'  + {post.author.username}: {post.text[:60]}')

        self.stdout.write(self.style.SUCCESS(f'Створено постів: {created}/{count}'))
