from django import template
from django.utils import timezone

register = template.Library()


@register.filter
def is_liked(post, user):
    return post.is_liked_by(user)


# Мапить час публікації поста на "настрій дня" — це і є візуальна
# "фішка" стрічки: тонка кольорова смужка зліва картки перетворює її
# на щось на кшталт живого щоденника (ранок/день/вечір/ніч).
_MOODS = (
    (5, 11, 'mood-morning', 'ранок'),
    (11, 17, 'mood-day', 'день'),
    (17, 22, 'mood-evening', 'вечір'),
)


@register.simple_tag
def mood_info(dt):
    if not dt:
        return {'cls': 'mood-day', 'label': 'день'}
    hour = timezone.localtime(dt).hour
    for start, end, cls, label in _MOODS:
        if start <= hour < end:
            return {'cls': cls, 'label': label}
    return {'cls': 'mood-night', 'label': 'ніч'}
