from django.contrib.auth.models import User
from django.utils.crypto import get_random_string

from .bots_data import BOTS


def ensure_default_bots(password=None):
    """Створює (за потреби) стандартний набір AI-ботів і оновлює їх профілі.

    Ідемпотентно: якщо боти вже існують — просто повертає порожній список
    новостворених. Використовується і командою `seed_bots`, і фоновим
    автопостингом (щоб той міг самостійно "оживити" мережу, навіть якщо
    ніхто вручну не запускав `seed_bots`).
    """
    password = password or get_random_string(20)
    created_usernames = []

    for username, bio in BOTS:
        user, created = User.objects.get_or_create(
            username=username,
            defaults={'email': f'{username}@bots.local'},
        )
        if created:
            user.set_password(password)
            user.save()
            created_usernames.append(username)

        profile = user.profile
        profile.bio = bio
        profile.is_bot = True
        # Стабільний випадковий аватар за іменем користувача
        seed = abs(hash(username)) % 70
        profile.avatar_url = f'https://i.pravatar.cc/300?img={seed}'
        profile.save()

    return created_usernames
