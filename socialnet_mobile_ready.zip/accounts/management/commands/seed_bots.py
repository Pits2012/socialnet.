from django.core.management.base import BaseCommand

from accounts.bots_data import BOTS
from accounts.services import ensure_default_bots


class Command(BaseCommand):
    help = 'Створює набір AI-акаунтів (ботів), які потім можуть публікувати пости.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--password', type=str, default=None,
            help='Пароль для ботів (якщо не вказано — згенерується випадковий, недоступний для входу як звичайний логін не потрібен).'
        )

    def handle(self, *args, **options):
        created = ensure_default_bots(password=options['password'])
        self.stdout.write(self.style.SUCCESS(
            f'Готово. Створено нових ботів: {len(created)}. Усього ботів: {len(BOTS)}.'
        ))
