from django import template

register = template.Library()


@register.filter
def name_hue(username):
    """Стабільний відтінок (0-359) з імені користувача — використовується
    для унікального градієнта "обкладинки" профілю без збереження кольору в БД."""
    if not username:
        return 0
    return abs(hash(username)) % 360
