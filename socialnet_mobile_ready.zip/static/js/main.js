document.addEventListener('DOMContentLoaded', () => {

    // ---------- 0a. Ripple-ефект на кнопках ----------
    document.body.addEventListener('click', (e) => {
        const btn = e.target.closest('button, input[type=submit], .primary');
        if (!btn) return;

        const rect = btn.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size = Math.max(rect.width, rect.height);
        ripple.className = 'ripple';
        ripple.style.width = ripple.style.height = `${size}px`;
        ripple.style.left = `${(e.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2}px`;
        ripple.style.top = `${(e.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2}px`;

        const computedPosition = getComputedStyle(btn).position;
        if (computedPosition === 'static') btn.style.position = 'relative';
        btn.style.overflow = 'hidden';

        btn.appendChild(ripple);
        ripple.addEventListener('animationend', () => ripple.remove());
    });

    // ---------- 0b. Плавний перехід між сторінками ----------
    // При кліку на звичайне внутрішнє посилання спершу програємо
    // "затухання" сторінки, і лише потім переходимо за посиланням —
    // тоді на новій сторінці одразу спрацьовує pageFadeIn з CSS.
    document.body.addEventListener('click', (e) => {
        const link = e.target.closest('a[href]');
        if (!link) return;
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
        if (link.target === '_blank' || link.hasAttribute('download')) return;

        const url = new URL(link.href, window.location.href);
        if (url.origin !== window.location.origin) return;
        // Посилання на цю ж сторінку (лише якір) — не анімуємо
        if (url.pathname === window.location.pathname && url.hash) return;

        e.preventDefault();
        document.body.classList.add('page-leaving');
        window.setTimeout(() => { window.location.href = link.href; }, 180);
    });

    window.addEventListener('pageshow', () => {
        document.body.classList.remove('page-leaving');
    });

    // ---------- 1. Reveal-анімація карток при появі у в'юпорті ----------
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

    function observeReveals(root) {
        root.querySelectorAll('.reveal:not(.in-view)').forEach((el) => revealObserver.observe(el));
    }
    observeReveals(document);

    // ---------- 2. AJAX-лайк з анімацією серця ----------
    document.body.addEventListener('submit', async (e) => {
        const form = e.target;
        if (!form.classList.contains('like-form')) return;
        e.preventDefault();

        const btn = form.querySelector('button');
        const countEl = btn.querySelector('.like-count');
        const csrfInput = form.querySelector('[name=csrfmiddlewaretoken]');

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': csrfInput ? csrfInput.value : '',
                },
            });
            if (!response.ok) throw new Error('Помилка мережі');
            const data = await response.json();

            btn.classList.toggle('liked', data.liked);
            if (countEl) countEl.textContent = data.count;

            if (data.liked) {
                btn.classList.remove('pulse');
                void btn.offsetWidth; // рестарт анімації
                btn.classList.add('pulse');
            }
        } catch (err) {
            // якщо щось пішло не так — звичайний сабміт форми як запасний варіант
            form.submit();
        }
    });

    // ---------- 3. Нескінченне гортання стрічки ----------
    const postList = document.getElementById('post-list');
    const sentinel = document.getElementById('scroll-sentinel');

    if (postList && sentinel) {
        let nextPage = parseInt(sentinel.dataset.nextPage || '2', 10);
        let loading = false;
        let hasMore = true;

        const scrollObserver = new IntersectionObserver(async (entries) => {
            if (!entries[0].isIntersecting || loading || !hasMore) return;

            loading = true;
            sentinel.classList.add('loading');

            try {
                const resp = await fetch(`/api/posts/?page=${nextPage}`, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                const data = await resp.json();

                if (data.html && data.html.trim()) {
                    postList.insertAdjacentHTML('beforeend', data.html);
                    observeReveals(postList);
                }

                hasMore = data.has_next;
                nextPage = data.next_page || nextPage + 1;

                if (!hasMore) {
                    sentinel.outerHTML = '<p class="feed-end">Це всі пости. Загляньте пізніше 👋</p>';
                }
            } catch (err) {
                hasMore = false;
            } finally {
                sentinel.classList && sentinel.classList.remove('loading');
                loading = false;
            }
        }, { rootMargin: '600px 0px' });

        scrollObserver.observe(sentinel);
    }
});
